import streamlit as st
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import seaborn as sns
import matplotlib.pyplot as plt

# Page Configuration
st.set_page_config(page_title="AI Network Intrusion Detection", layout="wide")

# Title and Description
st.title("🛡️ AI-Based Network Intrusion Detection System")
st.markdown("### Real-time Network Security Monitoring Dashboard")

# Sidebar
st.sidebar.header("⚙️ Control Panel")
st.sidebar.markdown("---")

# Function to generate simulated network traffic data
def generate_data(n_samples=1000):
    np.random.seed(42)
    
    # Features: packet_size, duration, protocol_type, port_number, flag_count
    packet_size = np.random.randint(20, 1500, n_samples)
    duration = np.random.uniform(0.1, 10, n_samples)
    protocol_type = np.random.randint(0, 3, n_samples)  # 0=TCP, 1=UDP, 2=ICMP
    port_number = np.random.randint(1, 65535, n_samples)
    flag_count = np.random.randint(0, 10, n_samples)
    
    # Create anomalies (20% of data)
    labels = np.zeros(n_samples)
    anomaly_indices = np.random.choice(n_samples, size=int(n_samples * 0.2), replace=False)
    labels[anomaly_indices] = 1
    
    # Anomalies have different patterns
    packet_size[anomaly_indices] = np.random.randint(1400, 1500, len(anomaly_indices))
    duration[anomaly_indices] = np.random.uniform(8, 10, len(anomaly_indices))
    flag_count[anomaly_indices] = np.random.randint(7, 10, len(anomaly_indices))
    
    df = pd.DataFrame({
        'packet_size': packet_size,
        'duration': duration,
        'protocol_type': protocol_type,
        'port_number': port_number,
        'flag_count': flag_count,
        'label': labels
    })
    
    return df

# Initialize session state
if 'model_trained' not in st.session_state:
    st.session_state.model_trained = False
    st.session_state.model = None
    st.session_state.accuracy = 0
    st.session_state.data = None

# Sidebar: Train Model
if st.sidebar.button("🚀 Train Model Now"):
    with st.spinner("Training Random Forest Classifier..."):
        # Generate data
        df = generate_data(1000)
        st.session_state.data = df
        
        # Prepare features and labels
        X = df[['packet_size', 'duration', 'protocol_type', 'port_number', 'flag_count']]
        y = df['label']
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
        
        # Train model
        model = RandomForestClassifier(n_estimators=100, random_state=42)
        model.fit(X_train, y_train)
        
        # Evaluate
        y_pred = model.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        
        # Save to session
        st.session_state.model = model
        st.session_state.accuracy = accuracy
        st.session_state.model_trained = True
        
    st.sidebar.success(f"✅ Model Trained! Accuracy: {accuracy:.2%}")

# Display model status
if st.session_state.model_trained:
    st.sidebar.success("✅ Model Status: ACTIVE")
    st.sidebar.metric("Accuracy", f"{st.session_state.accuracy:.2%}")
else:
    st.sidebar.warning("⚠️ Model Status: NOT TRAINED")
    st.sidebar.info("Click 'Train Model Now' to begin")

st.sidebar.markdown("---")

# Main Content Area
tab1, tab2, tab3 = st.tabs(["📊 Dashboard", "🔍 Live Detection", "📈 Analytics"])

with tab1:
    st.header("System Overview")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Total Packets Analyzed", "1,000")
    with col2:
        st.metric("Normal Traffic", "800", delta="80%")
    with col3:
        st.metric("Threats Detected", "200", delta="20%", delta_color="inverse")
    
    st.markdown("---")
    
    if st.session_state.model_trained:
        st.subheader("📉 Traffic Distribution")
        
        df = st.session_state.data
        
        # Create visualizations
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
        
        # Pie chart
        labels_count = df['label'].value_counts()
        ax1.pie(labels_count.values, labels=['Normal', 'Anomaly'], autopct='%1.1f%%', colors=['#2ecc71', '#e74c3c'])
        ax1.set_title('Traffic Classification')
        
        # Bar chart
        protocol_dist = df.groupby(['protocol_type', 'label']).size().unstack(fill_value=0)
        protocol_dist.plot(kind='bar', ax=ax2, color=['#2ecc71', '#e74c3c'])
        ax2.set_title('Protocol Distribution')
        ax2.set_xlabel('Protocol Type (0=TCP, 1=UDP, 2=ICMP)')
        ax2.set_ylabel('Count')
        ax2.legend(['Normal', 'Anomaly'])
        ax2.set_xticklabels(ax2.get_xticklabels(), rotation=0)
        
        st.pyplot(fig)
    else:
        st.info("🎯 Train the model to see analytics and visualizations")

with tab2:
    st.header("Live Traffic Simulator")
    
    if st.session_state.model_trained:
        st.markdown("### Enter Network Packet Parameters")
        
        col1, col2 = st.columns(2)
        
        with col1:
            packet_size = st.slider("Packet Size (bytes)", 20, 1500, 500)
            duration = st.slider("Duration (seconds)", 0.1, 10.0, 2.0)
            flag_count = st.slider("Flag Count", 0, 10, 3)
        
        with col2:
            protocol = st.selectbox("Protocol Type", ["TCP (0)", "UDP (1)", "ICMP (2)"])
            protocol_value = int(protocol.split("(")[1].split(")")[0])
            port = st.number_input("Port Number", 1, 65535, 8080)
        
        if st.button("🔍 Analyze Packet"):
            # Prepare input
            input_data = np.array([[packet_size, duration, protocol_value, port, flag_count]])
            
            # Predict
            prediction = st.session_state.model.predict(input_data)[0]
            probability = st.session_state.model.predict_proba(input_data)[0]
            
            st.markdown("---")
            st.subheader("🎯 Detection Result")
            
            if prediction == 1:
                st.error("🚨 **THREAT DETECTED!** This packet shows anomalous behavior.")
                st.warning(f"Confidence: {probability[1]:.2%}")
            else:
                st.success("✅ **NORMAL TRAFFIC** - No threats detected.")
                st.info(f"Confidence: {probability[0]:.2%}")
            
            # Show packet details
            with st.expander("📦 Packet Details"):
                st.json({
                    "Packet Size": f"{packet_size} bytes",
                    "Duration": f"{duration} seconds",
                    "Protocol": protocol,
                    "Port": port,
                    "Flags": flag_count
                })
    else:
        st.warning("⚠️ Please train the model first using the sidebar control panel.")

with tab3:
    st.header("Model Performance Analytics")
    
    if st.session_state.model_trained:
        st.metric("Model Accuracy", f"{st.session_state.accuracy:.2%}")
        
        st.markdown("### Feature Importance")
        feature_names = ['Packet Size', 'Duration', 'Protocol', 'Port', 'Flags']
        importances = st.session_state.model.feature_importances_
        
        fig, ax = plt.subplots(figsize=(10, 5))
        ax.barh(feature_names, importances, color='#3498db')
        ax.set_xlabel('Importance Score')
        ax.set_title('Feature Importance in Threat Detection')
        st.pyplot(fig)
        
        st.markdown("### Model Information")
        st.info("""
        **Algorithm:** Random Forest Classifier
        - **Number of Trees:** 100
        - **Training Samples:** 700
        - **Test Samples:** 300
        - **Features:** 5 network parameters
        """)
    else:
        st.info("Train the model to view performance metrics")

# Footer
st.markdown("---")
st.markdown("🔒 **AI-NIDS** | Powered by Machine Learning | Built with Streamlit")